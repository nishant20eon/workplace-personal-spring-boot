package com.car.carshowroom.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.car.carshowroom.controller.service.CarService;
import com.car.carshowroom.controller.service.MyCarService;
import com.car.carshowroom.entity.Car;
import com.car.carshowroom.entity.MyCarList;

@Controller
public class CarController {
	@Autowired
	private CarService service;
	
	@Autowired
	private MyCarService myCarService;
	
	@GetMapping("/")
	public String homePage() {
		return "home";
	}
	
	@GetMapping("/car_resister")
	public String CarRegister() {
		return "carRegister";
	}
	
	@GetMapping("/available_car")
	public ModelAndView getAllCar() {
		List<Car> list = service.getAllCar();
		ModelAndView m = new ModelAndView();
		m.setViewName("carlist");
		m.addObject("car", list);
		// return new ModelAndView("Carlist","Car",list);
		return m;
	}
	
	@PostMapping("/save")
	public String addCar(@ModelAttribute Car b) {
		service.save(b);
		return "redirect:/available_car";
	}
	
	@GetMapping("/my_cars")
	public String getMyCars(Model model) {
		List<MyCarList> allMyCar = myCarService.getAllMyCar();
		model.addAttribute("car", allMyCar);
		return "myCar";
	}
	
	@RequestMapping("/mylist/{id}")
	public String getMyList(@PathVariable("id") int id) {
		Car c = service.getCarById(id);
		MyCarList mb = new MyCarList(c.getCarId(),c.getCarName(),c.getCarModel(),c.getCarPrice());
		myCarService.saveMyCar(mb);
		return "redirect:/my_cars";
	}
	

	@RequestMapping("/editcar/{id}")
	public String CarEdit(@PathVariable("id") int id, Model model) {
		Car c = service.getCarById(id);
		model.addAttribute("car", c);
		return "carEdit";
		
	}
	
	
	@RequestMapping("/deletecar/{id}")
	public String deleteCar(@PathVariable("id") int id) {
		service.deleteById(id);
			return "redirect:/available_car";
		}

}
