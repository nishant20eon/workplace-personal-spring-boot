package com.car.carshowroom.controller.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.car.carshowroom.entity.MyCarList;
import com.car.carshowroom.repository.MyCarRepository;

@Service
public class MyCarService {
	
	@Autowired
	private MyCarRepository myCarrepo;
	
	public void saveMyCar(MyCarList car) {
		myCarrepo.save(car);
	}
	
	public List<MyCarList> getAllMyCar() {
		return myCarrepo.findAll();
	}
	
	public void deleteById(int id) {
		myCarrepo.deleteById(id);
		
	}

}
