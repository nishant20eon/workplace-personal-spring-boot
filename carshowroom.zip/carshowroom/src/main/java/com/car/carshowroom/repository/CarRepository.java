package com.car.carshowroom.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.car.carshowroom.entity.Car;
public interface CarRepository extends JpaRepository<Car, Integer>{

}
