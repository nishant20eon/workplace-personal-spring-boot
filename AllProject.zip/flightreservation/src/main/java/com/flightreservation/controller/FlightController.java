package com.flightreservation.controller;

import java.sql.Date;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class FlightController {
	
	@GetMapping("/findFlights")
	public String showFindFlits() {
		return "findFlights";
	}
	
	@PostMapping
	public String findFlights(String from, String to, Date departureDate) {
		return "displayFlights";
	}

}
