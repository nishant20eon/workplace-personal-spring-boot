package com.flightreservation.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.flightreservation.entities.Passenger;

public interface PassengerRepostiory extends JpaRepository<Passenger, Long> {

}
