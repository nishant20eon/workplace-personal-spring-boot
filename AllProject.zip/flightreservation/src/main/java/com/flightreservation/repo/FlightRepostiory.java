package com.flightreservation.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.flightreservation.entities.Flight;

public interface FlightRepostiory extends JpaRepository<Flight, Long> {

}
