package com.flightreservation.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.flightreservation.entities.Reservation;

public interface ReservationRepostiory extends JpaRepository<Reservation, Long> {

}
