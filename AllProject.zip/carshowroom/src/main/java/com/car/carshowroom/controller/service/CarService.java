package com.car.carshowroom.controller.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.car.carshowroom.entity.Car;
import com.car.carshowroom.repository.CarRepository;

@Service
public class CarService {
		@Autowired
		private CarRepository repository;
		
		public void save(Car b) {
			repository.save(b);
			
		}
		
		public List<Car> getAllCar() {
			return repository.findAll();
		}
		
		public Car getCarById(int id) {
			return repository.findById(id).get();
		}

		public void deleteById(int id) {
			// TODO Auto-generated method stub
			repository.deleteById(id);
			
		}

}