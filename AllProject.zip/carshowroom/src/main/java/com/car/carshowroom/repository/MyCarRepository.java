package com.car.carshowroom.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.car.carshowroom.entity.MyCarList;

public interface MyCarRepository extends JpaRepository<MyCarList, Integer>{

}
