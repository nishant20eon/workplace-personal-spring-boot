package com.car.carshowroom;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.car.carshowroom.entity.Student;
import com.car.carshowroom.repository.StudentRepository;



@SpringBootTest
class CarshowroomApplicationTests {

	@Autowired
	private StudentRepository repo;

	@Test
	void testCreateStudent() {
		Student student = new Student();
		student.setName("John1");
		student.setCourse("Serverless using AWS Lambda");
		student.setFee(30d);
		repo.save(student);
	}

}
