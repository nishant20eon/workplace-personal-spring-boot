package com.customer.dal;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.customer.dal.entities.Customer;
import com.customer.dal.repo.CustomerRepostiory;

@SpringBootTest
class CustomerdalApplicationTests {
	@Autowired
	private CustomerRepostiory repo;
	
	@Test
	void insertCustomerInfo() {
		
		Customer c = new Customer();
		c.setEmail("jhon@gmail.com");
		c.setName("Jhon");
		repo.save(c);
		
	}
	
	@Test
	void getCustInfo() {
		
		List<Customer> all = repo.findAll();
		for(Customer c : all)
			System.out.println(c);
		
	}
	
	@Test
	void deleteById() {
		repo.deleteById(1);
		getCustInfo();
		
	}

}
