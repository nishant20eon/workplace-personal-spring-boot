package com.customer.dal.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.customer.dal.entities.Customer;

public interface CustomerRepostiory extends JpaRepository<Customer, Integer> {

}
