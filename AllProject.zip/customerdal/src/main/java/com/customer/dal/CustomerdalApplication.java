package com.customer.dal;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CustomerdalApplication {

	public static void main(String[] args) {
		SpringApplication.run(CustomerdalApplication.class, args);
	}

}
