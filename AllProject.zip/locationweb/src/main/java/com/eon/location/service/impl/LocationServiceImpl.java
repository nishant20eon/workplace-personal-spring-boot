package com.eon.location.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.eon.location.entities.Location;
import com.eon.location.repo.LocationRepository;
import com.eon.location.service.LocationService;

@Service
public class LocationServiceImpl implements LocationService{
	@Autowired
	private LocationRepository repo;

	@Override
	public Location saveLocation(Location loc) {
		// TODO Auto-generated method stub
		return repo.save(loc);
	}

	@Override
	public Location updateLocation(Location loc) {
		// TODO Auto-generated method stub
		return repo.save(loc);
	}

	@Override
	public void deleteLocationbyId(Location loc) {
		// TODO Auto-generated method stub
		repo.delete(loc);
		
	}

	@Override
	public Location findLocByid(int id) {
		// TODO Auto-generated method stub
		return repo.findById(id).get();
	}

	@Override
	public List<Location> findAllLocation() {
		// TODO Auto-generated method stub
		return repo.findAll();
				
	}

}
