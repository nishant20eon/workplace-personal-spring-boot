package com.eon.location.service;

import java.util.List;

import com.eon.location.entities.Location;

public interface LocationService {

	Location saveLocation(Location loc);

	Location updateLocation(Location loc);

	void deleteLocationbyId(Location loc);

	Location findLocByid(int id);

	List<Location> findAllLocation();

}
