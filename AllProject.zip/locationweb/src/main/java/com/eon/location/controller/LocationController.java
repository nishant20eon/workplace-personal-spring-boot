package com.eon.location.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.eon.location.entities.Location;
import com.eon.location.repo.LocationRepository;
import com.eon.location.service.LocationService;
import com.eon.location.util.EmailUtil;
import com.eon.location.util.ReportUtil;

import jakarta.servlet.ServletContext;

@Controller
public class LocationController {
	@Autowired
	private LocationService service;
	@Autowired
	private EmailUtil emailutil;
	@Autowired
	private ReportUtil reportUtil;
	@Autowired
	private ServletContext sc;
	
	@Autowired
	private LocationRepository repo;
	
	
	
	@GetMapping("/showCreate")
	String showCreate() {
		return "createLocation";
	}
	
	@PostMapping("/saveLoc")
	String saveLocation(@ModelAttribute Location location, ModelMap modelMap) {
		Location saveLocation = service.saveLocation(location);
		String msg = "Location saved with id: " + saveLocation.getId();
		modelMap.addAttribute("msg", msg);
		emailutil.sendEmail("nishant20eon@gmail.com", "Location saved",
				"Location saved sucessfully and about send response");
		return "createLocation";

	}

	@GetMapping("/displayLocations")
	 String displayLoc(ModelMap modelMap) {
		List<Location> locations = service.findAllLocation();
		modelMap.addAttribute("locations",locations);
		return "displayLocations";
		
	}
	
	@GetMapping("/deleteLocation")
	String deleteById(@RequestParam int id,ModelMap modelMap ) {
		service.deleteLocationbyId(service.findLocByid(id));
		modelMap.addAttribute("locations",service.findAllLocation());
		return "displayLocations";
	}
	
	@GetMapping("/showUpdate")
	String showUpdate(@RequestParam int id,ModelMap modelMap) {
		Location location = service.findLocByid(id);
		modelMap.addAttribute("location",location);
		return "updateLocation";
	}
	
	@PostMapping("/updateLoc")
	String updateLocation(@ModelAttribute Location location, ModelMap modelMap){
		service.updateLocation(location);
		modelMap.addAttribute("locations",service.findAllLocation());
		return "displayLocations";
		
	}
	
	@RequestMapping("/generateReport")
	public String generateReport() {
		String path = sc.getRealPath("/");
		List<Object[]> data = repo.findTypeAndTypeCount();
		reportUtil.generatePieChart(path, data);
		return "report";
	}
	

}
