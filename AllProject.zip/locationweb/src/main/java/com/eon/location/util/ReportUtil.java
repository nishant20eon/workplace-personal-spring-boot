package com.eon.location.util;

import java.util.List;

public interface ReportUtil {
	
	void generatePieChart(String path, List<Object[]> data);

}
