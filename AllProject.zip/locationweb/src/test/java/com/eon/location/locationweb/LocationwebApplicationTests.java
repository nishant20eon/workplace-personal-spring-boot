package com.eon.location.locationweb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LocationwebApplicationTests {

	@Test
	void contextLoads() {
	}

}
