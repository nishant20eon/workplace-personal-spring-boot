package com.eon.student.dal;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.eon.student.dal.entity.Student;
import com.eon.student.dal.repo.StudentRepository;



@SpringBootTest
class StudentdalApplicationTests {

	@Autowired
	private StudentRepository repo;

	@Test
	void testCreateStudent() {
		Student student = new Student();
		student.setName("John2");
		student.setCourse("Serverless using AWS Lambda");
		student.setFee(30d);
		repo.save(student);
	}
	
	@Test
	void testFindsStudentById() {
		List<Student> all = repo.findAll();
		for(Student s: all) {
			System.out.println("123: "+s);
		}
		
	}

}
